from .vimeo90k_video import Vimeo90kDataset

__all__ = [
    "Vimeo90Dataset",
]
