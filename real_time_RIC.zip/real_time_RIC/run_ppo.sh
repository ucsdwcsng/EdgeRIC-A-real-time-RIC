
echo "cd runRL"
cd runRL

echo "python3 ppo_train.py" 
sudo python3 ppo_train.py

